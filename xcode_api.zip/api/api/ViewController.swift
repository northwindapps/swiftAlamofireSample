//
//  ViewController.swift
//  api
//
//  Created by yujin on 2019/05/21.
//  Copyright © 2019 yujin. All rights reserved.
//

import Alamofire
import SwiftyJSON
import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        let parameters: [String: Any] = ["email" : "bc@gmail.com",
        
        "password" : "123456",
        
        ]
        
        var url = "http://chatapp-env.q5v26m2d9e.ap-northeast-1.elasticbeanstalk.com/login"
        var token = ""
        
        print("URL :: \(url)")
        AF.request(url, method: .post, parameters: parameters, encoding: URLEncoding.httpBody, headers: nil)
            .responseString { response in
                print("RESPONSE2 :: \(response)")
                if (response.data != nil) {
                    print(response.data!)
               }
        }
        
    token="eyJpdiI6IjFNSTl3ZVIwZStZaEQzNlUrbFE4U0E9PSIsInZhbHVlIjoiUTlmN2h2aXdNSXkzaDI2TVZVZTAyamhHb1JyQ3hQN3hFY0x5T0ZoUkUrYXU4WGZLSEl6MkRzdVlMMW16ZU1pcSIsIm1hYyI6ImQyZmJkMWE1NTY2NjE3M2YyZDIzNjEzYTY1NjdiODk0M2ViMWMxNGFlMDJhNDg0ZTNkOTQzNWM4MWExNTRjODMifQ%3D%3D"
        
        //print(token)
        
        let theheader: HTTPHeaders  = ["Authorization" : "" + token, "Content-Type": "application/json"]
        

        url = "http://chatapp-env.q5v26m2d9e.ap-northeast-1.elasticbeanstalk.com/users"
        print("URL :: \(url)")
        AF.request(url, method: .get, parameters: nil, encoding: URLEncoding.httpBody, headers: theheader)
        
        .responseJSON { response in
            print("RESPONSE4 :: \(response)")
            
        }
        
        
        url = "http://chatapp-env.q5v26m2d9e.ap-northeast-1.elasticbeanstalk.com/posts"
        print("URL :: \(url)")
        AF.request(url, method: .get, parameters: nil, encoding: URLEncoding.httpBody, headers: theheader)
            
            .responseJSON { response in
                print("RESPONSE5 :: \(response)")
                
        }
        
        
    }


}
